<?php
$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "tiny";

$conn       = new mysqli($servername, $username, $password , $dbname);
if($conn->connect_error){
  die("Conection failed: " .$conn->connect_error);
}

$stmt = $conn->prepare("INSERT INTO upload (subject) VALUES (?) ");
$stmt->bind_param("s", $subject);

$subject = $_POST['subject'];
$stmt->execute();

echo "new record created succesfully";
$conn->close();




 ?>
