<?php
require_once 'functions/db.php';
require_once 'functions/tiny.php';
?>
